
function addCounter(ProductCode) {

  var value = document.getElementById("cartCounter").innerHTML;

  var strings = value.split(')');
  strings = strings[0].replace('(', '');
  strings = parseInt(strings) + 1;
  document.getElementById("cartCounter").innerHTML = '(' + strings  + ') Shopping cart';


  var data = {};
  data['ProductCode'] = ProductCode;

  targetUrl = '/cakephp/products/add-to-cart';
$.ajax({
   type: 'POST',
   url: targetUrl,
   data: data,
   success: function( data ) {
       //alert("joo");
   },
   error: function(ts) {
       alert("ei");
       alert(ts.responseText);
   },
   dataType: 'text'
});
 

}
