
<!--Make a link to shopping cart and show item count-->
<?php  echo $this->Html->link('('. $productCounter . ') Shopping cart', ['action' => 'show_cart'], ['class' => 'button', 'id' => 'cartCounter']); ?>

<!--This link directs to the add product page-->
<?= $this->Html->link('Add Product', ['class' => 'button', 'action' => 'add'], ['class' => 'button', 'id' => 'floatRight']) ?>

<!--This link resets the search-->
<h1><?= $this->Html->link('Simple shop', ['action' => 'index', true]) ?></h1>

<?php
    //This makes the search form
    //If there is data in the 'searchData' session variable, 
    //it will be inputted as default value to the search field
    echo $this->Form->create();

    if($searchData != null){
        echo $this->Form->control('search', [
            'label' => false,
            'default' => $searchData,
        ]);
    }else{
        echo $this->Form->control('search', [
            'label' => false,
        ]);
    }

    echo $this->Form->button(__('Search'));
    echo $this->Form->end();
?>

<table>
    <tr>
        <!--Basic pagination-->
        <th><?php echo $this->Paginator->sort('product_code'); ?></th>
        <th><?php echo $this->Paginator->sort('product_name'); ?></th>
        <th><?php echo $this->Paginator->sort('product_description'); ?></th>
        <th><?php echo $this->Paginator->sort('product_price'); ?></th>
        <th></th>
    </tr>

    <!--Loops through products in the database and displays their information-->
    <?php foreach ($products as $product): ?>
    <tr>
        <td>
            <?= $this->Html->link($product->product_code, ['action' => 'view', $product->product_code])  ?>
        </td>
        <td>
            <?= $this->Html->link($product->product_name, ['action' => 'view', $product->product_code])  ?>
        </td>
        <td>
            <?php
                //Making product description shorter for main page display
                $description = $product->product_description;
                if(strlen($description) > 55){
                    $description = substr($description, 0, 54) . "...";
                }
            ?>
            <?= $this->Html->link($description, ['action' => 'view', $product->product_code])  ?>          
        </td>
        <td>
            <?= $this->Html->link($product->product_price, ['action' => 'view', $product->product_code])  ?>
        </td>
        <td>
            <!--This button activates ajax call to put product in the cart and advance
                shopping cart counter-->
            <button onclick="addCounter(<?=$product->product_code?>)">Add to cart</button>
        </td>
    </tr>
    <?php endforeach; ?>
    <?php
        //Setting templates for paginator page link buttons
        $this->Paginator->setTemplates([
            'nextActive' => '<a class="button" href="{{url}}">{{text}}</a>',
            'nextDisabled' => '<a class="button inactive" disabled id href="{{url}}">{{text}}</a>',
            'prevActive' => '<a class="button" href="{{url}}">{{text}}</a>',
            'prevDisabled' => '<a class="button inactive" disabled href="{{url}}">{{text}}</a>'
        ]);
    ?>
    <tr> 
        <td>
          <?php echo $this->Paginator->prev('Previous'); ?> 
        </td> 
        <td></td>
        <td></td>
        <td>
            <?php echo $this->Paginator->next('Next'); ?>
        </td> 
    </tr>
</table>


<?php echo $this->Html->script('addToCart'); ?>

