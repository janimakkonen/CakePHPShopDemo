
<?= $this->Html->link('Back to main page', ['action' => 'index', true], ['class' => 'button']) ?>

<h1>Add Product</h1>
<?php
    echo $this->Form->create($product);
    echo $this->Form->control('product_name');
    echo $this->Form->control('product_description', ['rows' => '5']);
    echo $this->Form->control('product_price');
    echo $this->Form->button(__('Save Product'));
    echo $this->Form->end();
?>