
<?= $this->Html->link('Back to main page', ['action' => 'index'], ['class' => 'button']) ?>
<!--Make a link to shopping cart and show item count-->
<?php echo $this->Html->link('('. $productCounter . ') Shopping cart', ['action' => 'show_cart'], ['class' => 'button floatRight', 'id' => 'cartCounter']); ?>


<h2>Product information</h2>
<p><b>Product code:</b> <?= h($product->product_code) ?></p>
<p><b>Name:</b> <?= h($product->product_name) ?></p>
<p><b>Description:</b> <?= h($product->product_description) ?></p>
<p><b>Price:</b> <?= h($product->product_price) ?></p>
<!--This button activates ajax call to put product in the cart and advance
shopping cart counter-->
<button onclick="addCounter(<?=$product->product_code?>)">Add to cart</button>

<?php echo $this->Html->script('addToCart'); ?>