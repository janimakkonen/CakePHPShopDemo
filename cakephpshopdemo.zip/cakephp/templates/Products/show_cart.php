<!-- File: templates/Products/index.php -->
<h2><?= $this->Html->link('Back to mainpage', ['action' => 'index'], ['class' => 'button']) ?></h2>
<h1>Shopping cart</h1>


<table>
    <tr>
    	<th></th>
        <th>Product_code</th>
        <th>Product name</th>
        <th>Product prize</th>
        <th>Product count</th>
        <th>Total prize</th>
        <th></th>
    </tr>
    <?php $prizeTotal = 0;?>

    <!--This iterates through shopping cart and shows item information-->
    <?php foreach ($products as $product): ?>
    <tr>
    	<td>
    	</td>
        <td>
            <?= h($product['product_code']) ?>
        </td>
        <td>
            <?= h($product['product_name'])  ?>
        </td>
        <td>
         	<?= h($product['product_price'])  ?>
        </td>
        <td>
         	<?= h($product['product_count'])  ?>   
        </td>
        <td>
        	<?php 
        		$prizeTotal += $product['product_price']*$product['product_count'];
        		echo $product['product_price']*$product['product_count']; 
        	?>
        </td>
        <td>
          	<?php
                //This removes an item form the shopping cart
    	 		echo $this->Html->link('Remove', ['action' => 'delete_from_cart', $product['product_code']], ['class' => 'button']);
			?>
  
        </td>
 
    </tr>
    <?php endforeach; ?>
    <tr>
    	<td>
    		<b>Total price</b>
    	</td>
    	<td>
    	</td>
    	<td>
    	</td>
    	<td>
    	</td>
    	<td>
    	
    	</td>
    	<td>
    		<?=$prizeTotal?>
    	</td>

    </tr>
</table>


<?php echo $this->Html->script('addToCart'); ?>

