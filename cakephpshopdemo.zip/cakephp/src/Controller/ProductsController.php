<?php


namespace App\Controller;

use Cake\Http\Exception\NotFoundException;

class ProductsController extends AppController
{

	public function initialize(): void
    {
        parent::initialize();

        //Loading needed components
        $this->loadComponent('Paginator');
        $this->loadComponent('Flash'); 
    }

	public function index($resetData = false)
    {
  		$data = $this->request->getData();
        $session = $this->request->getSession();
        $this->set('searchData', '');

        //Setting max item limit to 10 on the main page
        $settings = [
                'maxLimit' => 10
        ];
            

        //Reset data if set true
        if($resetData){
            $data = '';
            $session->write('searchData', '');
            $resetData = false;
            $this->set('searchData', '');
            $this->redirect(['action' => 'index']);
        }

        //If there is search data
    	if($this->request->getData()){
            
            //Saving data to session
            $session->write('searchData', $data['search']);
    		
            //If search is with prouduct code
    		$convertedCode = (int)$data['search'];

            //Setting variable searchData for the view
            $this->set('searchData', $data['search']);

            //Doing a query with a product code or product name depending on the search data
            try {
                $products = $this->Paginator->paginate($this->Products->find()->where(['OR' => ['product_code LIKE' => $convertedCode, 'product_name LIKE' => '%' . $data['search'] .'%']]), $settings); 
            } catch (NotFoundException $e) {
                //Do this if pagination goes to a page which does not exist
                $products = array();
                $this->redirect(array('action' => 'index', 'page' => 0));


            }
    	}
        //Do this is session variable is set and seach data is not set
        else if($session->read('searchData') != null){
            
            $convertedCode = (int)$session->read('searchData');
            $this->set('searchData', $session->read('searchData'));

            //Doing a query with a product code or product name depending on the search data
            $products = $this->Paginator->paginate($this->Products->find()->where(['OR' => ['product_code LIKE' => $convertedCode, 'product_name LIKE' => '%' . $session->read('searchData') .'%']]), $settings);        
        }
        else{
            //Find all prouducts
    		$products = $this->Paginator->paginate($this->Products->find(), $settings);	
    	}

        //Setting productCounter variable for the view
        if($session->read('productCounter') != null){
            $this->set('productCounter', $session->read('productCounter'));
        }else{
            $session->write('productCounter', '0');
            $this->set('productCounter', '0');
        }
        
        //Set productCart variable for the view
        $this->set('productCart', $session->read('productCart'));
        $this->set(compact('products'));
    }

    //This shows product information of one product
    public function view($product_code = null)
	{

    	$product = $this->Products->find()->where(['product_code' => $product_code])->first();

        $session = $this->request->getSession();

        //Setting productCounter variable for the view
        if($session->read('productCounter') != null){
            $this->set('productCounter', $session->read('productCounter'));
        }else{
            $session->write('productCounter', '0');
            $this->set('productCounter', '0');
        }

    	$this->set(compact('product'));
	}

    //This add a product to the database
	public function add()
    {
        $product = $this->Products->newEmptyEntity();
        if ($this->request->is('post')) {
            $product = $this->Products->patchEntity($product, $this->request->getData());

            if ($this->Products->save($product)) {
                $this->Flash->success(__('Your product has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('Unable to add your product.'));
        }
        $this->set('product', $product);
    }

    //This adds a product to the shopping cart
    public function addToCart()
    {
        //Dont want to render a view for this
        $this->autoRender = false;

        $data = $this->request->getData();
        $session = $this->request->getSession();
        $productCode = $data['ProductCode'];
        $productCart = array();

        //Add one to product counter if not null
        //Otherwise set it to 1
        if($session->read('productCounter') != null){
            $session->write('productCounter', $session->read('productCounter') + 1);
        }else{
            $session->write('productCounter', '1');   
        }
        
        
        //This saves a product to productCart session array
        if($session->read('productCart') != null){
            $productCart = $session->read('productCart');
            if (array_key_exists($productCode, $productCart)) {
                $productCart[$productCode]++;
            } else {
                $productCart[$productCode] = 1;
            }
            $session->write('productCart', $productCart);
        }else{
            $productCart[$productCode] = 1;
            $session->write('productCart', $productCart);   
        }

        $session->write('productCart', $productCart);

        $this->set('productCounter', $session->read('productCounter'));

    }

    //This removes an item for the shopping cart
    public function deleteFromCart($productCode){

        //Get cart from the session
        $session = $this->request->getSession();
        $cart = $session->read('productCart');
        $product = $cart[$productCode];

        //subtract removed products count from the productCounter
        $countRemove = (int)$session->read('productCounter') - $product;
        $session->write('productCounter', $countRemove);
        if($session->read('productCounter') == null ){
            $session->write('productCounter', '0');    
        }

        //Remove product from the cart
        unset($cart[$productCode]);  
        $session->write('productCart', $cart);
        //return to shopping cart
        return $this->redirect(['action' => 'showCart']);
    }

    //Shows all the products in the shopping cart
    public function showCart(){
        $session = $this->request->getSession();
        $products = array();

        //Checks if product cart exists. If not send empty array to view.
        if($session->read('productCart') != null){
            $cart = $session->read('productCart');

            //Prepares products for the view
            foreach ($cart as $productCode => $productCount) {

                $tmpProduct = $this->Products->find()->where(['product_code' => $productCode])->first();

                $product['product_code'] = $tmpProduct['product_code'];
                $product['product_name'] = $tmpProduct['product_name'];
                $product['product_price'] = $tmpProduct['product_price'];
                $product['product_count'] = $productCount;

                $products[]=$product;

            }
            $this->set('products', $products);
        }else{
            $this->set('products', $products);
        }
    }


}	